This module counts the amount of integers in the two input arrays that are close together. 
Close being defined by a user input tcc.