// correlation_module.c

#include <Python.h>
#include "correlation.h"
#include <numpy/arrayobject.h>

static PyObject *correlate_wrapper(PyObject *self, PyObject *args)
{
    PyObject *tagsA_obj, *tagsB_obj;
    int sizeA, sizeB, tcc;

    if (!PyArg_ParseTuple(args, "OOiii", &tagsA_obj, &tagsB_obj, &sizeA, &sizeB, &tcc))
        return NULL;

    ///////////////
    // // Import NumPy API and get pointers to array data
    // import_array();

    // PyObject *tagsA_array = PyArray_FROM_OTF(tagsA_obj, NPY_INT64, NPY_ARRAY_IN_ARRAY);
    // PyObject *tagsB_array = PyArray_FROM_OTF(tagsB_obj, NPY_INT64, NPY_ARRAY_IN_ARRAY);

    // if (tagsA_array == NULL || tagsB_array == NULL) {
    //     PyErr_SetString(PyExc_TypeError, "Failed to convert input arrays to NumPy arrays");
    //     Py_XDECREF(tagsA_array);
    //     Py_XDECREF(tagsB_array);
    //     return NULL;
    // }
    // ///////////////

    long long int *tagsA = (long long int *)PyArray_DATA(tagsA_obj);
    long long int *tagsB = (long long int *)PyArray_DATA(tagsB_obj);

    int result = correlate(tagsA, tagsB, sizeA, sizeB, tcc);

    ///////////////
    // Py_DECREF(tagsA_array);
    // Py_DECREF(tagsB_array);
    ///////////////

    return PyLong_FromLong(result);
}

static PyMethodDef module_methods[] = {
    {"correlate", correlate_wrapper, METH_VARARGS, "Calculate correlation"},
    {NULL, NULL, 0, NULL}};

static struct PyModuleDef module_definition = {
    PyModuleDef_HEAD_INIT,
    "tomtag",
    NULL,
    -1,
    module_methods};

PyMODINIT_FUNC PyInit_tomtag(void)
{
    return PyModule_Create(&module_definition);
}
